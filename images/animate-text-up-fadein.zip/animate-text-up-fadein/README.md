# Animate Text Up & FadeIn

A Pen created on CodePen.io. Original URL: [https://codepen.io/mathelme/pen/nYJJoz](https://codepen.io/mathelme/pen/nYJJoz).

This is just a basic animation that fades up and in using css3 properties.